cd Desktop
cd 'custom wordle'
git add --all
git commit -m "send with send.sh"
git push -u origin master
